package com.yumi.android;

public class YumiDemoConstancts {

}
